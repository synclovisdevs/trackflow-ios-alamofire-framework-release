//
//  Trackflow.h
//  Trackflow
//
//  Created by Anooj Krishnan G on 03/09/20.
//  Copyright © 2020 Synclovis Systems Pvt Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for Trackflow.
FOUNDATION_EXPORT double TrackflowVersionNumber;

//! Project version string for Trackflow.
FOUNDATION_EXPORT const unsigned char TrackflowVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Trackflow/PublicHeader.h>


